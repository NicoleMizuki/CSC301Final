<?php
session_start();
require_once('pdo.php');
deleteRecipe($pdo,[$_SESSION['userID']]);
?>