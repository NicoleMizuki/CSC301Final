<?php
require_once('pdo.php');
signout();
?>